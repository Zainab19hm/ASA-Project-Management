import json
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from services.ai_service import call_model, WBS_PROMPT, GANTT_PROMPT, RISK_PROMPT, QA_PROMPT

app = FastAPI()

class ScopeInput(BaseModel):
    scope_text: str

class QAInput(BaseModel):
    question: str

@app.post("/wbs")
async def generate_wbs(input: ScopeInput):
    try:
        result = call_model(WBS_PROMPT, input.scope_text)
        data = json.loads(result)
        with open("wbs_output.json", "w") as f:
            json.dump(data, f, indent=2)
        return data
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))

@app.post("/gantt")
async def generate_gantt(input: ScopeInput):
    try:
        result = call_model(GANTT_PROMPT, input.scope_text)
        data = json.loads(result)
        with open("gantt_output.json", "w") as f:
            json.dump(data, f, indent=2)
        return data
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))

@app.post("/risk")
async def generate_risk(input: ScopeInput):
    try:
        result = call_model(RISK_PROMPT, input.scope_text)
        data = json.loads(result)
        with open("risk_output.json", "w") as f:
            json.dump(data, f, indent=2)
        return data
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))

@app.post("/qa")
async def answer_question(input: QAInput):
    try:
        result = call_model(QA_PROMPT, input.question)
        return {"answer": result}
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))